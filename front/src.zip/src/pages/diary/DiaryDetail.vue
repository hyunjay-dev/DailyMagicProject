<template>
    <div>
        <diary-detail-form></diary-detail-form>
    </div>
</template>
<script>
import DiaryDetailForm from '@/components/diary/DiaryDetailForm'

export default {
    name:'DiaryDetail',
    components:{DiaryDetailForm}
}
</script>