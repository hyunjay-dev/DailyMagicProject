<template>
    <div class="Diary">
        <diary-list-form></diary-list-form>
    </div>
</template>

<script>

import DiaryListForm from '@/components/diary/DiaryListForm'

export default {
    name: "DiaryList",
    components: {DiaryListForm},
}
</script>

<style scoped>

</style>