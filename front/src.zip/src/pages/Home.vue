<template>
  <div align="center">
    <h1>Daily Magic</h1>
    <p>{{getTime()}}</p>
  </div>
</template>

<script>
export default {
  name: 'Home',
  methods: {
    getTime() {
      return new Date().toString()
    }
  }
}
</script>
