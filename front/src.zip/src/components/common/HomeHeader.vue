<template>
    <div align="center">
        <router-link :to="{name:'Home'}">홈</router-link>
    </div>
</template>

<script>
export default {
    name: 'HomeHeader'
}
</script>