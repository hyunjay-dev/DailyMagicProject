<template>
    <div align="enter">
        <p> &copy; 2020 ALL RIGHT RESERVED </p>
    </div>
</template>

<script>
export default {
    name: 'Footer'
}
</script>